"""
A program that takes two files as command line arguments, one a DNA sequence
and the other a csv list of names with their DNA profiles, and matches 
the DNA sequence with the person
"""

import csv
import sys

def main():
    # Initialising variables as strings with default values, to be updated later
    s_t_r = "STR Name"
    sequence = "DNA Sequence"
    dna_list = ['0', '0', '0', '0', '0', '0', '0', '0', '0']
    
    # Ensure program is run with two command line arguments
    if len(sys.argv) != 3:
        print("Usage: python dna.py data.csv sequence.txt")
        sys.exit(1)
    
    # Storing DNA sequence from argv[2] as a string
    f = open(sys.argv[2])
    sequence = f.read()
    f.close()
    
    
    # Opening CSV file to get STR names and search for them in DNA sequence:
    with open(sys.argv[1]) as csvfile:
        column_count = 0 # number of columns in csv file, corresponds to number of STRs to check
        reader = csv.reader(csvfile)
        line_count = 0
        
        for row in reader:
            # Only reads first line of CSV file
            if line_count == 0:
                # Gets length of first line of CSV file
                for x in row:
                    column_count += 1
                # Gets names of columns (i.e. STR names) from CSV file, saves them as list (dna_list)
                for x in range(0, column_count, 1):
                    s_t_r = row[x]
                    dna_list[x] = str_search(sequence, s_t_r)
                line_count += 1 # ensures this code is only performed once
                
            if line_count >= 1:
                if dna_list[1:column_count] == row[1:column_count]:
                    print(row[0])
                    return
                line_count += 1
                
    # Using return keyword, this line is never reached unless no match is found
    print("No match")

# Function that searches a DNA sequence for a given STR and returns longest number of consecutive repetitions
def str_search(a, b): # a is a DNA sequence, b is an STR
    
    longest = 0 # Counts longest consecutive string of STR repetitions
    x = (int)(len(a) / len(b)) # Highest theoretical # of reps (i.e. if entire sequence is consecutive STRs)
    
    for i in range(1, x, 1):
        if (b * i) in a:
            longest += 1
            continue
        else:
            break
        
    longest_str = str(longest)
    return longest_str
        
main()